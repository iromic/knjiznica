<!DOCTYPE html>
<html>
    <head>
    <style>
        
        th,td,tr{
            border: 1px solid black;
        }
        </style>
    </head>
    <body>

<?php
//get the q parameter from url
$q = $_REQUEST["q"];

$hint = "";

// lookup all hints from array if $q is different from "" 
if ($q !== "") {
    $q = strtolower($q);
    $len=strlen($q);
    

//Spremi konekciju s bazom u varijablu ("root", "root" - to su user i pass za moju bazu)
$conn = mysqli_connect("localhost", "root", "", "knjiznica");

//Ako konekcija s bazom nije uspostavljena, ispisi error
if (!$conn) {
    die('Connect Error: '.mysqli_connect_errno());
}

$sql = "SELECT ime,prezime, naziv_knjige,autor
            FROM student s
            JOIN posudba p ON p.id_studenta= s.id
            JOIN knjiga k ON p.id_knjige= k.id
            JOIN autor a ON a.id=k.id_autora
            WHERE ime LIKE   '" . $_GET["q"] . "%' OR prezime LIKE  '" . $_GET["q"] . "%' ";


$rez= mysqli_query($conn, $sql);

    
    echo "<table class='table table-striped table-bordered table-hover'>
							<thead>
							<tr>
							<th>Ime</th>
							<th>Prezime</th>
							<th>Naziv knjige</th>
							</tr>
							</thead>";

while($rows = mysqli_fetch_array($rez)){
    
   // $ime= $rows["ime"];
    //$prezime= $rows["prezime"];
    //$naziv_knjige= $rows["naziv_knjige"];
    //$autor= $rows["autor"];
    
  

    

   echo "<tbody><tr>";
    echo "<td>" . $rows['ime'] . "</td>";
    echo "<td>" . $rows['prezime'] . "</td>";
    echo "<td>" . $rows['naziv_knjige'] . "</td>";
    echo "</tbody></tr>";
}
echo "</table>";
}


    


else {
    echo "greska";
}


    
?>
        
    </body>
</html>