<DOCTYPE html>
<html>
  <head>
  </head>
  <body>
    <header>
      <a href='./'>Početna</a>
     
	  <a href='?controller=autor&action=index'>Autori</a>
	    
    </header>

    <?php require_once('routes.php'); ?>

    <footer>
      Copyright
    </footer>
  <body>
<html>