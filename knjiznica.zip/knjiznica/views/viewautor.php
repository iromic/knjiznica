<html>
<head></head>

<body>

<?php 

	echo 'id:' . $autor->id . '<br/>';
	echo 'naziv:' . $autor->naziv_autora . '<br/>';
	

?>

</body>
</html>