<p>This is result of autor DELETE </p>

<p><?php echo $autor; ?></p>
