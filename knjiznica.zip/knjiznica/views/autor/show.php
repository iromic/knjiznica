<p>This is detailed viw of autor:</p>

<p><?php echo $autor->id; ?></p>
<p><?php echo $autor->naziv_autora; ?></p>
