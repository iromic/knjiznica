<html>
<head></head>

<body>

<table>
	<tr><td><pre>ID</pre> </td><td><pre>naziv autora </pre> </td></tr> 
	<?php 

		foreach ($autor as $naziv => $autor)
		{
			
			echo '<tr><td><a href="mvc.php?id='.$autor->id.'">'.$autor->id.'</a></td><td>'.$autor->naziv_autora.'</td></tr>';
		}

	?>
</table>

</body>
</html>