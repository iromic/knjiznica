<!DOCTYPE html>
<html>
    <head>
	<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Knjiznica</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    </head>
    <body>
<?php
//get the q parameter from url
$q = $_REQUEST["q"];

$hint = "";

// lookup all hints from array if $q is different from "" 
if ($q !== "") {
    $q = strtolower($q);
    $len=strlen($q);
    

//Spremi konekciju s bazom u varijablu ("root", "root" - to su user i pass za moju bazu)
$conn = mysqli_connect("localhost", "root", "", "knjiznica");

//Ako konekcija s bazom nije uspostavljena, ispisi error
if (!$conn) {
    die('Connect Error: '.mysqli_connect_errno());
}

$sql = "SELECT ime,prezime, naziv_knjige
            FROM student s
            JOIN posudba p ON p.id_studenta= s.id
            JOIN knjiga k ON p.id_knjige= k.id
            JOIN autor a ON a.id=k.id_autora
            WHERE ime LIKE   '" . $_GET["q"] . "%' OR prezime LIKE  '" . $_GET["q"] . "%' ";


 echo "<table class='table table-striped table-bordered table-hover'>
							<thead>
							<tr>
							<th>Ime</th>
							<th>Prezime</th>
							<th>Naziv knjige</th>
							</tr>
							</thead>";

$rez= mysqli_query($conn, $sql);

while($rows = mysqli_fetch_array($rez)){
	
    echo "<tbody><tr>";
    echo "<td>" . $rows['ime'] . "</td>";
    echo "<td>" . $rows['prezime'] . "</td>";
    echo "<td>" . $rows['naziv_knjige'] . "</td>";
    echo "</tbody></tr>";
}
echo "</table>";


}
    


else {
    echo "greska";
}

?>
        
    </body>
</html>