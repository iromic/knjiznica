<html>
<head></head>

<body>

<?php 

	echo 'id:' . $tvrtka->id . '<br/>';
	echo 'naziv:' . $tvrtka->naziv_autora . '<br/>';

?>

</body>
</html>