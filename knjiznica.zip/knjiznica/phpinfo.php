<?php

phpinfo();
 ?>