--
-- Database: `knjiznica`
--

-- --------------------------------------------------------

--
-- Table structure for table `autor`
--

CREATE TABLE `autor` (
  `ID` int(11) NOT NULL,
  `naziv_autora` varchar(510) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `autor`
--

INSERT INTO `autor` (`ID`, `naziv_autora`) VALUES
(1, 'August Senoa'),
(2, 'Ivo Andric'),
(3, 'Tin Ujevic');

-- --------------------------------------------------------

--
-- Stand-in structure for view `autor1`
--
CREATE TABLE `autor1` (
`ID` int(11)
,`naziv_autora` varchar(510)
);

-- --------------------------------------------------------

--
-- Table structure for table `clanarina`
--

CREATE TABLE `clanarina` (
  `ID` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `datum_uplate` datetime DEFAULT NULL,
  `datum_isteka` datetime DEFAULT NULL,
  `iznos_clanarine` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clanarina`
--

INSERT INTO `clanarina` (`ID`, `student_id`, `datum_uplate`, `datum_isteka`, `iznos_clanarine`) VALUES
(1, 1, '2017-01-16 00:00:00', '2017-12-30 00:00:00', 10),
(2, 2, '2017-01-22 00:00:00', '2017-12-30 00:00:00', 10),
(3, 3, '2017-01-16 00:00:00', '2017-12-30 00:00:00', 10),
(4, 4, '2017-02-06 00:00:00', '2017-12-30 00:00:00', 10),
(5, 5, '2017-01-16 00:00:00', '2017-12-30 00:00:00', 10),
(6, 6, '2017-03-10 00:00:00', '2017-12-30 00:00:00', 10);

-- --------------------------------------------------------

--
-- Table structure for table `fakultet`
--

CREATE TABLE `fakultet` (
  `ID` int(11) NOT NULL,
  `naziv_fakulteta` varchar(510) DEFAULT NULL,
  `adresa` varchar(510) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `fakultet`
--

INSERT INTO `fakultet` (`ID`, `naziv_fakulteta`, `adresa`) VALUES
(1, 'FSR', 'Matice  hrvatske'),
(2, 'EFMO', 'Matice hrvatske'),
(3, 'PMF', NULL),
(4, 'FFMO', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `izdavac`
--

CREATE TABLE `izdavac` (
  `ID` int(11) NOT NULL,
  `izdavac` varchar(510) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `izdavac`
--

INSERT INTO `izdavac` (`ID`, `izdavac`) VALUES
(1, 'Skolska knjiga'),
(2, 'Skolska naklada');

-- --------------------------------------------------------

--
-- Table structure for table `knjiga`
--

CREATE TABLE `knjiga` (
  `ID` int(11) NOT NULL,
  `naziv_knjige` varchar(510) DEFAULT NULL,
  `Autor` varchar(510) DEFAULT NULL,
  `id_vrsta_knjige` int(11) DEFAULT NULL,
  `id_autora` int(11) DEFAULT NULL,
  `id_izdavaca` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `knjiga`
--

INSERT INTO `knjiga` (`ID`, `naziv_knjige`, `Autor`, `id_vrsta_knjige`, `id_autora`, `id_izdavaca`) VALUES
(1, 'Nemiri', 'Ivo Andrić', 2, 1, 1),
(2, 'Zlatarevo zlato', 'August Senoa', 1, 2, 2),
(3, 'Auto na korzu', 'Tin Ujevic', 5, 3, 2),
(4, 'Na drini cuprija', 'Ivo Andric', 1, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `posudba`
--

CREATE TABLE `posudba` (
  `ID` int(11) NOT NULL,
  `datum_posudbe` datetime DEFAULT NULL,
  `datum_povratka` datetime DEFAULT NULL,
  `id_knjige` int(11) DEFAULT NULL,
  `id_studenta` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `posudba`
--

INSERT INTO `posudba` (`ID`, `datum_posudbe`, `datum_povratka`, `id_knjige`, `id_studenta`) VALUES
(1, '2017-01-03 00:00:00', '2017-03-13 00:00:00', 1, 1),
(2, '2017-02-07 00:00:00', '2017-04-02 00:00:00', 1, 3),
(3, '2017-03-13 00:00:00', '2017-04-11 00:00:00', 2, 2),
(4, '2017-03-27 00:00:00', NULL, 3, 4),
(5, '2017-04-16 00:00:00', NULL, 4, 5),
(6, '2017-03-27 00:00:00', '2017-04-16 00:00:00', 4, 6),
(9, '2017-03-13 00:00:00', '2017-04-06 00:00:00', 2, 7);

-- --------------------------------------------------------

--
-- Stand-in structure for view `posudbe`
--
CREATE TABLE `posudbe` (
`ime` varchar(510)
,`prezime` varchar(510)
,`naziv_knjige` varchar(510)
,`datum_posudbe` datetime
,`datum_povratka` datetime
);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `ID` int(11) NOT NULL,
  `ime` varchar(510) DEFAULT NULL,
  `prezime` varchar(510) DEFAULT NULL,
  `adresa` varchar(510) DEFAULT NULL,
  `id_fakulteta` int(11) DEFAULT NULL,
  `tel_broj` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`ID`, `ime`, `prezime`, `adresa`, `id_fakulteta`, `tel_broj`) VALUES
(1, 'Ivo', 'Iviv', '88000 Mostar', 2, 123545),
(2, 'Pero', 'Peric', 'Siroki Brijeg', 3, NULL),
(3, 'Ana', 'Ancic', 'Mostar', 4, 44785),
(4, 'Iva', 'Ivic', 'Posusje', 1, 455687),
(5, 'Monika', 'Monic', 'Citluk', 1, 4559782),
(6, 'Jure', 'Juric', 'Siroki Brijeg', 1, NULL),
(7, 'Mara', 'Antic', 'Mostar', 3, 236975);

-- --------------------------------------------------------

--
-- Table structure for table `vrsta_knjige`
--

CREATE TABLE `vrsta_knjige` (
  `ID` int(11) NOT NULL,
  `vrsta_knjige` varchar(510) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vrsta_knjige`
--

INSERT INTO `vrsta_knjige` (`ID`, `vrsta_knjige`) VALUES
(1, 'Roman'),
(2, 'Ep'),
(3, 'Novela'),
(4, 'Drama'),
(5, 'Zbirka pjesama');

-- --------------------------------------------------------

--
-- Structure for view `autor1`
--
DROP TABLE IF EXISTS `autor1`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `autor1`  AS  select `autor`.`ID` AS `ID`,`autor`.`naziv_autora` AS `naziv_autora` from `autor` ;

-- --------------------------------------------------------

--
-- Structure for view `posudbe`
--
DROP TABLE IF EXISTS `posudbe`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `posudbe`  AS  select `s`.`ime` AS `ime`,`s`.`prezime` AS `prezime`,`k`.`naziv_knjige` AS `naziv_knjige`,`p`.`datum_posudbe` AS `datum_posudbe`,`p`.`datum_povratka` AS `datum_povratka` from ((`posudba` `p` join `student` `s` on((`p`.`id_studenta` = `s`.`ID`))) join `knjiga` `k` on((`p`.`id_knjige` = `k`.`ID`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `autor`
--
ALTER TABLE `autor`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `clanarina`
--
ALTER TABLE `clanarina`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `FK_clanarina_student` (`student_id`);

--
-- Indexes for table `fakultet`
--
ALTER TABLE `fakultet`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `izdavac`
--
ALTER TABLE `izdavac`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `knjiga`
--
ALTER TABLE `knjiga`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `FK_knjiga_vrsta_knjige` (`id_vrsta_knjige`),
  ADD KEY `FK_knjiga_izdavac` (`id_izdavaca`),
  ADD KEY `FK_knjiga_autor` (`id_autora`);

--
-- Indexes for table `posudba`
--
ALTER TABLE `posudba`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `FK_posudba_knjiga` (`id_knjige`),
  ADD KEY `FK_posudba_student` (`id_studenta`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `FK_student_fakultet` (`id_fakulteta`);

--
-- Indexes for table `vrsta_knjige`
--
ALTER TABLE `vrsta_knjige`
  ADD PRIMARY KEY (`ID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `clanarina`
--
ALTER TABLE `clanarina`
  ADD CONSTRAINT `FK_clanarina_student` FOREIGN KEY (`student_id`) REFERENCES `student` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `knjiga`
--
ALTER TABLE `knjiga`
  ADD CONSTRAINT `FK_knjiga_autor` FOREIGN KEY (`id_autora`) REFERENCES `autor` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_knjiga_izdavac` FOREIGN KEY (`id_izdavaca`) REFERENCES `izdavac` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_knjiga_vrsta_knjige` FOREIGN KEY (`id_vrsta_knjige`) REFERENCES `vrsta_knjige` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `posudba`
--
ALTER TABLE `posudba`
  ADD CONSTRAINT `FK_posudba_knjiga` FOREIGN KEY (`id_knjige`) REFERENCES `knjiga` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_posudba_student` FOREIGN KEY (`id_studenta`) REFERENCES `student` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `FK_student_fakultet` FOREIGN KEY (`id_fakulteta`) REFERENCES `fakultet` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
